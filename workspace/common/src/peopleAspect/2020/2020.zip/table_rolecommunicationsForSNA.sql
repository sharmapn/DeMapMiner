
DROP table rolecommunicationsForSNA;
CREATE TABLE rolecommunicationsForSNA (authorsrole text, inReplyToUserUsingClusteredSenderRole text, cnt INTEGER);