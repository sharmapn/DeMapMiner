-- once the other script is done, the queries in this script are run...
-- the one to get proposalauthor values are in a different script



-- for messages which has pep as -1, some were replies to messages with pep number
-- so we set that here using th inreplyto columns
 
-- sample 
-- UPDATE all_distinctmessages AS a, (SELECT COUNT(messageID) as ct FROM all_distinctmessages WHERE inReplyTo = emailMessageID) AS p
-- SET a.countRepliesToThisMessage = p.ct
 
 -- SQL does not work
 -- UPDATE allmessages AS a, 
 -- (SELECT pep FROM allmessages m WHERE m.emailmessageid = a.inreplyto LIMIT 1) AS b
 -- SET a.pepnum2020 = b.pep
 
UPDATE allmessages a, allmessages b SET b.pepnum2020 = a.pep
WHERE b.emailmessageid = a.inreplyto AND b.pepnum2020 = -1;
-- this was needed
ALTER TABLE `allmessages` ADD INDEX `pepnum2020_index` (`pepnum2020`)
-- reset
UPDATE allmessages SET pepnum2020 = pep;

-- see if we found new rows
-- old pep num
SELECT pep, COUNT(messageid) FROM allmessages WHERE pep = 308 GROUP BY pep;
-- 2735
-- new pep num
SELECT pepnum2020, COUNT(messageid) FROM allmessages WHERE pepnum2020 = 308 GROUP BY pepnum2020;
-- 2762
--so we found a little bit more messages, for pep 308 we got 27 messagess

-- jan 2021, we can run it a second time to assign pep numbers to messages whch are replies to messages whoch we just assigned a pep number using the sql above

-- Results --------------------------------------------------------------------------------------------------------------------------------------------------------------------


-- DESC allmessages

-- try for this spcific query... seeders
SELECT pep, author, COUNT(messageid) AS totalmsgs,
  SUM(CASE WHEN inReplyTo IS NULL THEN 1 ELSE 0 END) As msg_which_are_not_replies, -- inReplyToUserUsingClusteredSender
  SUM(CASE WHEN inReplyTo IS NOT NULL THEN 1 ELSE 0 END) AS msg_which_are_replies
FROM allmessages
WHERE pep = 308
AND (folder LIKE '%dev%' OR folder LIKE '%ideas%')
GROUP BY author
ORDER BY msg_which_are_not_replies DESC

-- we have to combine with the below query
SELECT pep, inReplyToUserUsingClusteredSender, COUNT(inReplyTo) AS totalinReplyTo  -- inReplyTo, 
FROM allmessages
WHERE pep = 308
AND (folder LIKE '%dev%' OR folder LIKE '%ideas%')
GROUP BY inReplyToUserUsingClusteredSender  
ORDER BY totalinReplyTo desc
--- inReplyToUserUsingClusteredSender,
--  SUM(CASE WHEN inReplyTo IS NULL THEN 1 ELSE 0 END) As msg_which_are_not_replies, -- inReplyToUserUsingClusteredSender
--  SUM(CASE WHEN inReplyTo IS NOT NULL THEN 1 ELSE 0 END) AS msg_which_are_replies
-- inReplyToUserUsingClusteredSender, 

-- Final joining of the above query
SELECT * 
FROM (SELECT pep, author, COUNT(messageid) AS totalmsgs,
  			SUM(CASE WHEN inReplyTo IS NULL THEN 1 ELSE 0 END) As msg_which_are_not_replies, -- inReplyToUserUsingClusteredSender
  			SUM(CASE WHEN inReplyTo IS NOT NULL THEN 1 ELSE 0 END) AS msg_which_are_replies
		FROM allmessages
		WHERE pep = 308
		AND (folder LIKE '%dev%' OR folder LIKE '%ideas%')
		GROUP BY author
		ORDER BY msg_which_are_not_replies DESC) AS tbA
LEFT JOIN (SELECT inReplyToUserUsingClusteredSender, COUNT(inReplyTo) AS totalinReplyTo  -- inReplyTo, 
				FROM allmessages
				WHERE pep = 308
				AND (folder LIKE '%dev%' OR folder LIKE '%ideas%')
				GROUP BY inReplyToUserUsingClusteredSender  
				ORDER BY totalinReplyTo desc) as tbC
ON tbA.author = tbC.inReplyToUserUsingClusteredSender

-- just to test this on pep 308
SELECT pep, author, COUNT(messageid) AS totalmsgs,
  SUM(CASE WHEN inReplyTo IS NULL THEN 1 ELSE 0 END) As msg_which_are_not_replies, -- inReplyToUserUsingClusteredSender
  SUM(CASE WHEN inReplyTo IS NOT NULL THEN 1 ELSE 0 END) AS msg_which_are_replies
FROM allmessages
WHERE pep = 308
AND (folder LIKE '%dev%' OR folder LIKE '%ideas%')
GROUP BY author
ORDER BY msg_which_are_not_replies DESC

-- we have to combine with the below query
SELECT pep, inReplyToUserUsingClusteredSender, COUNT(inReplyTo) AS totalinReplyTo  -- inReplyTo, 
FROM allmessages
WHERE pep = 308
AND (folder LIKE '%dev%' OR folder LIKE '%ideas%')
GROUP BY inReplyToUserUsingClusteredSender  
ORDER BY totalinReplyTo DESC

-- now test the results 
SELECT *  -- author, -- *
-- author, totalmsgs AS TotalMsgByPerson, totalInReplyTo AS TotalMsgByPerson_whichGotReplies, msgs_not_replies AS TotalMsg_whichGotNoReplies 
from communicationsforseeders
ORDER BY totalmsgs desc

-- SELECT author, state , peptype, totalmsgs, msgs_not_replies, author_again, totalinreplyto, summessages, dominance_index
-- from communicationsforseeders
-- GROUP BY author, peptype, state
-- ORDER BY totalmsgs DESC

-- values for each member -- values summed for all peps
SELECT author, SUM(totalmsgs) AS SUM_totalmsgs, SUM(msgs_not_replies), SUM(totalinreplyto) -- , SUM(summessages) -- , dominance_index
from communicationsforseeders
GROUP BY author -- , peptype, state
ORDER BY SUM_totalmsgs DESC

-- COMBINE AUTHORS
UPDATE communicationsforseeders SET author = 'Nick Coghlan' WHERE author = 'nick.coghlan';
UPDATE communicationsforseeders SET author = 'Guido van Rossum' WHERE author = 'guido.van.rossum'; 
UPDATE communicationsforseeders SET author = 'Barry A. Warsaw' WHERE author = 'Barry Warsaw'; 
UPDATE communicationsforseeders SET author = 'Chris Angelico' WHERE author = 'chris.angelico'; 
UPDATE communicationsforseeders SET author = 'Paul Moore' WHERE author = 'paul.moore'; 
UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author = 'victor.stinner';
UPDATE communicationsforseeders SET author = 'Antoine Pitrou' WHERE author = 'antoine.pitrou';
UPDATE communicationsforseeders SET author = 'Tim Peters' WHERE author =	'tim.peters';
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author = 'ivan.levkivskyi';
--	'steven.d'aprano'
UPDATE communicationsforseeders SET author = 'Eric V. Smith' WHERE author = 'eric.v.smith';
UPDATE communicationsforseeders SET author = 'Barry A. Warsaw' WHERE author = 'barry.warsaw';
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author = 'serhiy.storchaka';
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author =	'lukasz.langa'
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author =	'lukasz'
UPDATE communicationsforseeders SET author = 'Brett Cannon' WHERE author =	'brett.cannon';
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author =	'nathaniel.smith'
UPDATE communicationsforseeders SET author = 'Greg Ewing' WHERE author =	'greg.ewing';
UPDATE communicationsforseeders SET author = 'Terry Reedy' WHERE author =	'terry.reedy';
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author =	'Martin v. Loewis' ?? can we find ANY others

-- JAN 2021 as above, we saw the same problems in the ammlessages table...some authors were not combined BECAUSE THE EMAIL address were totally different, i.e. python trackers
-- so we combine these
-- COMBINE AUTHORS
UPDATE allmessages SET clusterbysenderfullname = 'Nick Coghlan' 		WHERE clusterbysenderfullname IS NULL AND author = 'nick.coghlan';
UPDATE allmessages SET clusterbysenderfullname ='Guido van Rossum' 	WHERE clusterbysenderfullname IS NULL AND author = 'guido.van.rossum'; 
UPDATE allmessages SET clusterbysenderfullname = 'Barry A. Warsaw' 	WHERE clusterbysenderfullname IS NULL AND author = 'Barry Warsaw'; 
UPDATE allmessages SET clusterbysenderfullname = 'Chris Angelico' 	WHERE clusterbysenderfullname IS NULL AND author = 'chris.angelico'; 
UPDATE allmessages SET clusterbysenderfullname = 'Paul Moore' 			WHERE clusterbysenderfullname IS NULL AND author = 'paul.moore'; 
UPDATE allmessages SET clusterbysenderfullname = 'Victor Stinner' 	WHERE clusterbysenderfullname IS NULL AND author = 'victor.stinner';
UPDATE allmessages SET clusterbysenderfullname = 'Antoine Pitrou' 	WHERE clusterbysenderfullname IS NULL AND author = 'antoine.pitrou';
UPDATE allmessages SET clusterbysenderfullname ='Tim Peters' 			WHERE clusterbysenderfullname IS NULL AND author =	'tim.peters';
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author = 'ivan.levkivskyi';
--	'steven.d'aprano'
UPDATE allmessages SET clusterbysenderfullname = 'Eric V. Smith' 		WHERE clusterbysenderfullname IS NULL AND author = 'eric.v.smith';
UPDATE allmessages SET clusterbysenderfullname ='Barry A. Warsaw' 	WHERE clusterbysenderfullname IS NULL AND author = 'barry.warsaw';
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author = 'serhiy.storchaka';
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author =	'lukasz.langa'
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author =	'lukasz'
UPDATE allmessages SET clusterbysenderfullname = 'Brett Cannon' 		WHERE clusterbysenderfullname IS NULL AND author =	'brett.cannon';
-- UPDATE communicationsforseeders SET author = 'Victor Stinner' WHERE author =	'nathaniel.smith'
UPDATE allmessages SET clusterbysenderfullname = 'Greg Ewing' 			WHERE clusterbysenderfullname IS NULL AND author =	'greg.ewing';
UPDATE allmessages SET clusterbysenderfullname = 'Terry Reedy' 		WHERE clusterbysenderfullname IS NULL AND author =	'terry.reedy';
-- more combinations needed
UPDATE allmessages SET clusterbysenderfullname ='Barry A. Warsaw' 	WHERE clusterbysenderfullname = 'Barry A Warsaw';

CREATE or replace VIEW top10authors AS
	SELECT DISTINCT AUTHOR, SUM(totalmsgs) AS S FROM communicationsforseeders group by author ORDER BY s DESC LIMIT 20;

-- Now we change pep to pepnum2020 and author to clusterbysenderfullname for the main cursoe queries above
SELECT * FROM  communicationsforseeders
-- NOW MAIN QUERY ON THE RESULTS
-- First, FOR ALL MEMBERS
SELECT pep, LOWER(author), peptype, state, SUM(totalmsgs) AS TotalMsgsByPerson, SUM(msgs_not_replies) AS TotalTopLevelMsgsByPerson, 
SUM(msgs_are_replies) AS TotalRepliesByPersonToDiffMsgs, 
SUM(totalinreplyto) AS TotalRepliesToThisPerson, SUM(summessages) AS TotalMsgsForPEP -- , dominance_index
from communicationsforseeders
-- WHERE author IN (SELECT author FROM top10authors)
GROUP BY pep, LOWER(author) -- , peptype, state
ORDER BY TotalMsgsByPerson DESC -- (SELECT AUTHOR FROM communicationsforseeders ORDER BY SUM(totalmsgs) ) DESC

-- main script to get the computed cursor (previous script) results in the correct format
-- Second, only for top 20 by now grouping by for values for each member -- values summed for all peps
-- ANOTHER PART OF THE MAIN QUERY ... 
-- ALTER TABLE communicationsforseeders ADD COLUMN folder TEXT(30);
-- remove the folder column in this query and in the main cursor, both for top members andfor proposal author
				-- peptype,							-- state
SELECT author, 
	COUNT(distinct pep) AS pepInvolvement, SUM(totalmsgs) AS TotalMsgByPerson, 	-- SUM(totalmsgs)/COUNT(pep) AS AVEG, 
	SUM(msgs_not_replies) AS TotalTopLevelMsgsByPerson, 	-- SUM(msgs_not_replies)/COUNT(pep) AS AVEG2, 
	SUM(msgs_are_replies) AS TotalRepliesByPersonToDiffMsgs, 	-- SUM(msgs_are_replies)/COUNT(pep) AS AVEG3,
	SUM(totalinreplyto) AS TotalRepliesToThisPerson 	-- SUM(totalinreplyto)/COUNT(pep) AS AVEG4,
	-- SUM(summessages) AS TotalMsgsForPEP -- , dominance_index
from communicationsforseeders
-- WHERE author IN (SELECT author FROM top10authors)
WHERE (author IN (SELECT author FROM top10authors) OR author = 'proposalauthor'  OR author = 'bdfl_delegate' )
	GROUP BY author -- , folder -- , peptype -- , state -- , peptype, state
	ORDER BY pepInvolvement DESC, TotalMsgByPerson DESC

-- now sepration by dm sub-phase				
-- add folder in two places to get groups by folder from the same query
				-- folder
SELECT author, -- substring(folder,13), 
	CASE substring(folder,13) 
		WHEN 'python-ideas' THEN 'idea_generation'
		WHEN 'python-dev' THEN 'idea_discussion' WHEN 'python-checkins' THEN 'idea_discussion' 
		WHEN 'python-bugs-list' THEN 'idea_discussion' WHEN 'python-committers' THEN 'idea_discussion' 
		WHEN 'python-announce-list' THEN 'idea_discussion' WHEN 'python-distutils-sig' THEN 'idea_discussion'
		WHEN 'additional\\python-3000' THEN 'idea_discussion' 
		WHEN 'python-lists' THEN 'user_support'
	END AS DMsubphase,
	COUNT(distinct pep) AS pepInvolvement, SUM(totalmsgs) AS TotalMsgByPerson, 
	-- SUM(totalmsgs)/COUNT(pep) AS AVEG, 
	SUM(msgs_not_replies) AS TotalTopLevelMsgsByPerson, 
	-- SUM(msgs_not_replies)/COUNT(pep) AS AVEG2, 
	SUM(msgs_are_replies) AS TotalRepliesByPersonToDiffMsgs, 
	-- SUM(msgs_are_replies)/COUNT(pep) AS AVEG3,
	SUM(totalinreplyto) AS TotalRepliesToThisPerson 
	-- SUM(totalinreplyto)/COUNT(pep) AS AVEG4,
	-- SUM(summessages) AS TotalMsgsForPEP -- , dominance_index
from communicationsforseeders
-- WHERE author IN (SELECT author FROM top10authors)
WHERE (author IN (SELECT author FROM top10authors) OR author = 'proposalauthor'  OR author = 'bdfl_delegate' )
	GROUP BY author, DMsubphase -- folder -- , peptype -- , state -- , peptype, state
	ORDER BY pepInvolvement DESC, TotalMsgByPerson DESC -- AUTHOR -- SUM_totalmsgs DESC -- (SELECT AUTHOR FROM communicationsforseeders ORDER BY SUM(totalmsgs) ) DESC 

-- above query for bar chart
-- CREATE TABLE tstret as
SELECT author, -- substring(folder,13), 
	CASE substring(folder,13) 
		WHEN 'python-ideas' THEN 'idea_generation'
		WHEN 'python-dev' THEN 'idea_discussion' WHEN 'python-checkins' THEN 'idea_discussion' 
		WHEN 'python-bugs-list' THEN 'idea_discussion' WHEN 'python-committers' THEN 'idea_discussion' 
		WHEN 'python-announce-list' THEN 'idea_discussion' WHEN 'python-distutils-sig' THEN 'idea_discussion'
		WHEN 'additional\\python-3000' THEN 'idea_discussion' 
		WHEN 'python-lists' THEN 'user_support'
	END AS DMsubphase,
	-- COUNT(distinct pep) AS pepInvolvement, 
	SUM(totalmsgs) AS TotalMsgByPerson, 
	-- SUM(totalmsgs)/COUNT(pep) AS AVEG, 
	SUM(msgs_not_replies) AS TotalTopLevelMsgsByPerson, 
	-- SUM(msgs_not_replies)/COUNT(pep) AS AVEG2, 
	SUM(msgs_are_replies) AS TotalRepliesByPersonToDiffMsgs, 
	-- SUM(msgs_are_replies)/COUNT(pep) AS AVEG3,
	SUM(totalinreplyto) AS TotalRepliesToThisPerson 
	-- SUM(totalinreplyto)/COUNT(pep) AS AVEG4,
	-- SUM(summessages) AS TotalMsgsForPEP -- , dominance_index
from communicationsforseeders
WHERE 
-- author IN (SELECT author FROM top10authors)
 (author  LIKE '%guido%' or author LIKE 'nick co%' or author LIKE '%warsaw%'  or author = 'proposalauthor'  OR author = 'bdfl_delegate'  )  -- IN (SELECT author FROM top10authors)
	AND PEP IN (SELECT pep FROM bdflddpeps) -- for only the 50 peps from bdfl delegate select this line
	GROUP BY author, DMsubphase -- folder -- , peptype -- , state -- , peptype, state
	ORDER BY author ASC, DMsubphase ASC




-- now for the above query we only want to see those peps where the bdfl delegate made the decision
SELECT pep, bdfl_delegatecorrected, author, authorrole, bdfldelegaterole 
FROM pepdetails
WHERE LENGTH (bdfl_delegatecorrected) > 0
-- note can also be after PEP 572 
-- and also those PEPs which were not accepted or rejected
-- INSERT INTO top10authors (author) VALUES ('bdfl_delegate');

-- modified above query only for those peps with a delegate
				-- peptype,
SELECT author,  COUNT(pep) AS pepInvolvement, state, SUM(totalmsgs) AS TotalMsgByPerson, SUM(totalmsgs)/COUNT(pep) AS AVEG, 
	SUM(msgs_not_replies) AS TotalTopLevelMsgsByPerson, SUM(msgs_not_replies)/COUNT(pep) AS AVEG2, 
	SUM(msgs_are_replies) AS TotalRepliesByPersonToDiffMsgs, SUM(msgs_are_replies)/COUNT(pep) AS AVEG3,
	SUM(totalinreplyto) AS TotalRepliesToThisPerson, SUM(totalinreplyto)/COUNT(pep) AS AVEG4,
	SUM(summessages) AS TotalMsgsForPEP -- , dominance_index
from communicationsforseeders
WHERE (author IN (SELECT author FROM top10authors) OR author = 'bdfl_delegate' )
	AND PEP IN (SELECT pep FROM pepdetails WHERE LENGTH (bdfl_delegatecorrected) > 0 ) --   AND created < '2017-07-12'  )
GROUP BY author -- , peptype -- , state
ORDER BY pepInvolvement DESC, TotalMsgsForPEP DESC 

-- just to see which peps were rejected by bdfl delegate
SELECT * 
FROM (SELECT DISTINCT PEP, state, DATE2, peptype						
	FROM pepstates_danieldata_datetimestamp  
	WHERE (STATE LIKE '%acc%' OR state LIKE '%rej%') 
	AND PEP IN (SELECT pep FROM pepdetails WHERE LENGTH (bdfl_delegatecorrected) > 0 ) 
	order by DATE2 ASC)
	AS tbA
LEFT JOIN ( SELECT pep, author, bdfl_delegatecorrected FROM pepdetails ) as tbC
	ON tbA.pep = tbC.pep
ORDER BY tbA.pep;


SELECT * 
FROM pepdetails
WHERE state LIKE '%rej%' 
AND LENGTH (bdfl_delegatecorrected) > 0




-- SELECT * FROM pepstates_danieldata_datetimestamp

-- we have to add the proposalauthor values to the above two query results
SELECT authorsrole, COUNT(distinct pepnum2020)
FROM allmessages
WHERE pepnum2020 <> -1
GROUP BY authorsrole

SELECT pepnum2020, pep, messageid, fromline, senderemail, author, sendername,  senderfullname, clusterbysenderfullname, authorsrole, inreplytouserusingclusteredsenderrole
from allmessages 
-- giodo
-- WHERE (fromline LIKE '%guido%' OR fromline LIKE '%gvr%') -- put 'fromline' instead of author.... 'guido.van.rossum'
-- raymond hettinger
WHERE (fromline LIKE '%raymond%' OR fromline LIKE '%rhettinger%')
-- LIMIT 20
and pepnum2020 = 308
-- not all messages of raymond were assigned as from proposl author.
-- thus we have to assign emauils from the cluster...reflect the cluster

SELECT * FROM distinctsenders WHERE emailaddress LIKE '%hettinger%'
-- rhettinger@users.sourceforge.net, rhettinger

-- get all clusters details for cluster 1

-- now main dominance index clculation for each pepe for all peps
SELECT author,  avg(dominance_index) AS dom, sum(dominance_index)/248 AS sumdom
FROM communicationsforseeders
GROUP BY author, peptype
ORDER BY sumdom ASC
-- author, peptype, 

SELECT DISTINCT PEP, state, DATE2, peptype,
					(SELECT COUNT(messageid) FROM allmessages WHERE pep = m.pep AND (folder LIKE '%dev%' OR folder LIKE '%ideas%')) AS summessages
					FROM pepstates_danieldata_datetimestamp m 
					WHERE (STATE LIKE '%acc%' OR state LIKE '%rej%') order by DATE2 asc;



-- testing
SELECT pep, state, COUNT(state) AS totalstates 
FROM pepstates_danieldata_datetimestamp
-- WHERE pep = 308
-- AND (folder LIKE '%dev%' OR folder LIKE '%ideas%')
GROUP BY state  
ORDER BY totalstates desc
