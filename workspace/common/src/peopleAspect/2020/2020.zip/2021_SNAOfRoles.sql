-- this is the main script for sna or roles. It has all scripts and does not need any other python or java scripts

DROP TABLE pepinvolvement;
CREATE TABLE pepinvolvement AS 
	SELECT clusterBySenderFullName, COUNT(distinct pepnum2020) AS pepcount 
	FROM allmessages
	WHERE pepnum2020 > 0
	GROUP BY clusterBySenderFullName
	ORDER BY pepcount desc
	LIMIT 20;
--	SELECT * FROM pepinvolvement
-- DROP TABLE 2021_SNAofroles;
CREATE TABLE 2021_SNAofroles AS
	select clusterBySenderFullName, "," AS a , inReplyToUserUsingClusteredSender, "," AS b, 
				-- (select authorsrole FROM commonroles WHERE author = m.author ),  
				authorsrole," ," AS c, inReplyToUserUsingClusteredSenderRole, ",  " AS d,
				(select PEPCount FROM pepinvolvement WHERE clusterBySenderFullName = m.author ) AS pepinvolvementcount -- add number of peps the member has contributed in
		from allmessages m
		WHERE PEPnum2020 IN (SELECT PEP FROM allpepstillbdfl) 
				AND PEPnum2020 NOT IN (SELECT pep FROM pepdetails WHERE LENGTH (bdfl_delegatecorrected) > 0 ) 
		-- AND DATE2 < (SELECT DATE2 FROM accrejpeps WHERE PEP = m.PEP)
		-- jan 2021 we consider all lailing lists
		-- AND folder LIKE '%dev%'
		-- we want to see direct connections at the moment
		AND LENGTH(clusterBySenderFullName) > 0 
		AND LENGTH(inReplyToUser) > 0 
		-- AND (sendername in (select distinct(sendername) from alldevelopers) -- atleast one member is a developer
		-- OR inReplyToUser in (select distinct(sendername) from alldevelopers))
		order by clusterBySenderFullName;

-- DROP TABLE 2021_SNAorroles_bdfld;
CREATE TABLE 2021_SNAofroles_bdfld as
	select clusterBySenderFullName, " , " AS a, inReplyToUserUsingClusteredSender, "," AS b, 
				-- (select authorsrole FROM commonroles WHERE author = m.author ),  
				authorsrole, " ," AS c, inReplyToUserUsingClusteredSenderRole, ",  " AS d,
				(select PEPCount FROM pepinvolvement WHERE clusterBySenderFullName = m.author ) AS pepinvolvementcount -- add number of peps the member has contributed in
		from allmessages m
		WHERE PEPnum2020 IN (SELECT pep FROM pepdetails WHERE LENGTH (bdfl_delegatecorrected) > 0 )  -- (SELECT PEP FROM allpepstillbdfl) -- (SELECT pep FROM bdflddpeps)
		-- AND DATE2 < (SELECT DATE2 FROM accrejpeps WHERE PEP = m.PEP)
		-- jan 2021 we consider all lailing lists
		-- AND folder LIKE '%dev%'
		-- we want to see direct connections at the moment
		AND LENGTH(clusterBySenderFullName) > 0 
		AND LENGTH(inReplyToUser) > 0 
		-- AND (sendername in (select distinct(sendername) from alldevelopers) -- atleast one member is a developer
		-- OR inReplyToUser in (select distinct(sendername) from alldevelopers))
		order by clusterBySenderFullName;
		
	-- first to correct errors in assignment of roles by earlier sciprts
	UPDATE 2021_SNAofroles SET clusterBySenderFullName = 'bdfl'  						WHERE clusterBySenderFullName = 'guido van rossum';	
	UPDATE 2021_SNAofroles SET inReplyToUserUsingClusteredSender = 'bdfl'  			WHERE inReplyToUserUsingClusteredSender = 'guido van rossum';		
	UPDATE 2021_SNAofroles_bdfld SET clusterBySenderFullName = 'bdfl'  				WHERE clusterBySenderFullName = 'guido van rossum';	
	UPDATE 2021_SNAofroles_bdfld SET inReplyToUserUsingClusteredSender = 'bdfl'  	WHERE inReplyToUserUsingClusteredSender = 'guido van rossum';
-- now we set the node values for the nodes which are important roles		
-- easy way to do this .. we just set the authorsrole and inReplyToUserUsingClusteredSenderrole field 
	-- to the actual author unless they are proposalauthor or the bdfl_delegate or bdfl -- as thats what we a re interested in
	UPDATE 2021_SNAofroles SET clusterBySenderFullName = authorsrole  WHERE authorsrole = 'proposalAuthor' ;
	UPDATE 2021_SNAofroles SET clusterBySenderFullName = authorsrole  WHERE authorsrole = 'bdfl_delegate'; 
	UPDATE 2021_SNAofroles SET clusterBySenderFullName = authorsrole  WHERE authorsrole = 'bdfl';	
	UPDATE 2021_SNAofroles SET inReplyToUserUsingClusteredSender = inReplyToUserUsingClusteredSenderRole  WHERE inReplyToUserUsingClusteredSenderRole = 'proposalAuthor' ;
	UPDATE 2021_SNAofroles SET inReplyToUserUsingClusteredSender = inReplyToUserUsingClusteredSenderRole  WHERE inReplyToUserUsingClusteredSenderRole = 'bdfl_delegate' ;
	UPDATE 2021_SNAofroles SET inReplyToUserUsingClusteredSender = inReplyToUserUsingClusteredSenderRole  WHERE inReplyToUserUsingClusteredSenderRole = 'bdfl';
	
	UPDATE 2021_SNAofroles_bdfld SET clusterBySenderFullName = authorsrole  WHERE authorsrole = 'proposalAuthor' ;
	UPDATE 2021_SNAofroles_bdfld SET clusterBySenderFullName = authorsrole  WHERE authorsrole = 'bdfl_delegate'; 
	UPDATE 2021_SNAofroles_bdfld SET clusterBySenderFullName = authorsrole  WHERE authorsrole = 'bdfl';	
	UPDATE 2021_SNAofroles_bdfld SET inReplyToUserUsingClusteredSender = inReplyToUserUsingClusteredSenderRole  WHERE inReplyToUserUsingClusteredSenderRole = 'proposalAuthor' ;
	UPDATE 2021_SNAofroles_bdfld SET inReplyToUserUsingClusteredSender = inReplyToUserUsingClusteredSenderRole  WHERE inReplyToUserUsingClusteredSenderRole = 'bdfl_delegate' ;
	UPDATE 2021_SNAofroles_bdfld SET inReplyToUserUsingClusteredSender = inReplyToUserUsingClusteredSenderRole  WHERE inReplyToUserUsingClusteredSenderRole = 'bdfl';
		
SELECT * FROM 2021_SNAofroles
	INTO OUTFILE 'c:\\scripts\\SNA2020\\SNA_2021_AllDevelopers_20-01-2021_b.txt';
/* Affected rows: 39,705  Found rows: 0  Warnings: 0  Duration for 1 query: 2.403 sec. */
SELECT * FROM 2021_SNAofroles_bdfld
		INTO OUTFILE 'c:\\scripts\\SNA2020\\SNA_2021_OnlyBDFLDelegate_20-01-2021_c.txt';
/* Affected rows: 6,895  Found rows: 0  Warnings: 0  Duration for 1 query: 0.328 sec. */