SELECT * FROM pepdetails
SELECT * FROM proposaldetails
SELECT * FROM pythonmembers_coredevelopers
SELECT * FROM pepdmcontributionsbyrole

SELECT pep, author, authorrole, bdfldelegaterole
FROM pepdetails